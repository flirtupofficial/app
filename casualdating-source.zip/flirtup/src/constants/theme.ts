import { useColorScheme } from 'react-native';

const palette = {
  light: {
    primary: '#E23E63',
    onPrimary: '#FFFFFF',
    background: '#FFF7F9',
    card: '#FFFFFF',
    text: '#1B0F16',
    muted: '#7A6672',
    border: '#F0DDE4',
    danger: '#C62828',
    accent: '#8E2DE2',
    surface: '#FDEBF0',
  },
  dark: {
    primary: '#FF5C7A',
    onPrimary: '#1A0A10',
    background: '#120A10',
    card: '#1E121A',
    text: '#FDF2F6',
    muted: '#B39AA6',
    border: '#33202C',
    danger: '#FF6B6B',
    accent: '#B06BFF',
    surface: '#2A1622',
  },
};

export type Colors = typeof palette.light;

export function useColors(): Colors {
  return useColorScheme() === 'dark' ? palette.dark : palette.light;
}

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };

export const radius = { sm: 10, md: 16, lg: 24, pill: 999 };
