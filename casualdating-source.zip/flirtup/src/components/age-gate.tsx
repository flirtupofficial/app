import Ionicons from '@expo/vector-icons/Ionicons';
import { useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { SITE_URL } from '@/lib/data';

type Props = { onConfirm: () => void };

/** 18+ gate shown before anything else on first launch. */
export function AgeGate({ onConfirm }: Props) {
  const colors = useColors();
  const [checked, setChecked] = useState(false);
  const [refused, setRefused] = useState(false);

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={styles.body}>
        <View style={[styles.badge, { backgroundColor: colors.surface }]}>
          <Ionicons name="flame" size={40} color={colors.primary} />
        </View>
        <Text style={[styles.brand, { color: colors.text }]}>Flirtup</Text>
        <Text style={[styles.tagline, { color: colors.muted }]}>Casual dating for local singles</Text>

        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.title, { color: colors.text }]}>Adults only</Text>
          <Text style={[styles.copy, { color: colors.muted }]}>
            Flirtup is an 18+ platform for casual dating. By continuing you confirm you are at
            least 18 years old and accept the Terms and Privacy Policy.
          </Text>

          <Pressable
            accessibilityRole="checkbox"
            accessibilityState={{ checked }}
            onPress={() => setChecked((v) => !v)}
            style={styles.checkRow}>
            <View
              style={[
                styles.box,
                {
                  borderColor: checked ? colors.primary : colors.border,
                  backgroundColor: checked ? colors.primary : 'transparent',
                },
              ]}>
              {checked ? <Ionicons name="checkmark" size={16} color={colors.onPrimary} /> : null}
            </View>
            <Text style={[styles.checkLabel, { color: colors.text }]}>I am 18 or older</Text>
          </Pressable>

          <Button
            title="Enter Flirtup"
            icon="heart"
            disabled={!checked}
            onPress={onConfirm}
          />
          <Button
            title="I am under 18"
            variant="ghost"
            onPress={() => setRefused(true)}
          />
          {refused ? (
            <Text style={[styles.copy, { color: colors.danger }]}>
              Sorry — Flirtup is only for adults. Please close the app.
            </Text>
          ) : null}
        </View>

        <Pressable onPress={() => Linking.openURL(SITE_URL)} hitSlop={8}>
          <Text style={[styles.link, { color: colors.muted }]}>site.sinfulbuddies.com</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  body: { flex: 1, padding: spacing.lg, justifyContent: 'center', gap: spacing.sm },
  badge: {
    width: 76,
    height: 76,
    borderRadius: 38,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  brand: { fontSize: 34, fontWeight: '800', textAlign: 'center', letterSpacing: 0.5 },
  tagline: { fontSize: 15, textAlign: 'center', marginBottom: spacing.md },
  card: {
    borderRadius: radius.lg,
    borderWidth: StyleSheet.hairlineWidth,
    padding: spacing.lg,
    gap: spacing.md,
  },
  title: { fontSize: 20, fontWeight: '700' },
  copy: { fontSize: 14, lineHeight: 21 },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  box: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkLabel: { fontSize: 16, fontWeight: '600' },
  link: { fontSize: 13, textAlign: 'center', marginTop: spacing.md },
});
