import { StyleSheet, Text, View } from 'react-native';

import { initials } from '@/lib/data';

type Props = {
  name: string;
  tint: [string, string];
  size?: number;
  online?: boolean;
};

/** Initials avatar — the app ships without photos, so every profile gets a tinted badge. */
export function Avatar({ name, tint, size = 56, online }: Props) {
  return (
    <View style={{ width: size, height: size }}>
      <View
        style={[
          styles.circle,
          { width: size, height: size, borderRadius: size / 2, backgroundColor: tint[0] },
        ]}>
        <View
          style={[
            styles.overlay,
            { borderRadius: size / 2, backgroundColor: tint[1], opacity: 0.55 },
          ]}
        />
        <Text style={[styles.letter, { fontSize: size * 0.38 }]}>{initials(name)}</Text>
      </View>
      {online ? <View style={styles.dot} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  circle: { alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  overlay: { position: 'absolute', top: 0, start: 0, end: 0, bottom: 0 },
  letter: { color: '#FFFFFF', fontWeight: '800' },
  dot: {
    position: 'absolute',
    end: 0,
    bottom: 0,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#3ED6A8',
    borderWidth: 2,
    borderColor: '#120A10',
  },
});
