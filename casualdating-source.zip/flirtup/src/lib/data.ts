/**
 * Profile model and the sample profiles the app ships with.
 *
 * These are clearly-labelled sample profiles: the app has no connection to the Flirtup
 * member database, so it never pretends a real person is online. Real browsing and
 * chatting happen on the Flirtup site, which the app links to.
 */

export type Profile = {
  id: string;
  name: string;
  age: number;
  city: string;
  distanceKm: number;
  bio: string;
  interests: string[];
  lookingFor: string;
  online: boolean;
  verified: boolean;
  likesYou: boolean;
  /** Two hex colors used for the initials avatar. */
  tint: [string, string];
};

export type MyProfile = {
  name: string;
  age: string;
  city: string;
  bio: string;
  lookingFor: string;
};

export type ChatMessage = {
  id: string;
  from: 'me' | 'them';
  text: string;
  at: number;
};

export const SITE_URL = 'https://site.sinfulbuddies.com/';

export const LOOKING_FOR_OPTIONS = [
  'Casual dating',
  'Chat & flirting',
  'Dates & nights out',
  'Something fun, no strings',
  'Friends with benefits',
];

export const SAMPLE_PROFILES: Profile[] = [
  {
    id: 'p1',
    name: 'Mia',
    age: 27,
    city: 'Downtown',
    distanceKm: 2,
    bio: 'Coffee, vinyl and late-night drives. Looking for someone fun to trade bad jokes with.',
    interests: ['Live music', 'Coffee', 'Road trips'],
    lookingFor: 'Casual dating',
    online: true,
    verified: true,
    likesYou: true,
    tint: ['#FF5C7A', '#B06BFF'],
  },
  {
    id: 'p2',
    name: 'Alex',
    age: 31,
    city: 'Riverside',
    distanceKm: 4,
    bio: 'Gym in the morning, tacos at night. No drama, just good company.',
    interests: ['Fitness', 'Tacos', 'Dogs'],
    lookingFor: 'Chat & flirting',
    online: false,
    verified: true,
    likesYou: false,
    tint: ['#FF8A5B', '#FF3D71'],
  },
  {
    id: 'p3',
    name: 'Sofia',
    age: 24,
    city: 'Old Town',
    distanceKm: 1,
    bio: 'Art student, terrible at pool, excellent at playlists. Say hi if you like museums.',
    interests: ['Art', 'Pool', 'Playlists'],
    lookingFor: 'Dates & nights out',
    online: true,
    verified: false,
    likesYou: true,
    tint: ['#B06BFF', '#5B8CFF'],
  },
  {
    id: 'p4',
    name: 'Jordan',
    age: 29,
    city: 'Harbour',
    distanceKm: 6,
    bio: 'Weekend cook, weekday overthinker. Let us split a bottle of wine and argue about films.',
    interests: ['Cooking', 'Films', 'Wine'],
    lookingFor: 'Something fun, no strings',
    online: false,
    verified: true,
    likesYou: false,
    tint: ['#3ED6A8', '#2E8BFF'],
  },
  {
    id: 'p5',
    name: 'Nina',
    age: 33,
    city: 'Uptown',
    distanceKm: 3,
    bio: 'Travelled a lot, settled here. Looking for easy conversation and better plans.',
    interests: ['Travel', 'Yoga', 'Cocktails'],
    lookingFor: 'Casual dating',
    online: true,
    verified: true,
    likesYou: false,
    tint: ['#FFB03A', '#FF5C7A'],
  },
  {
    id: 'p6',
    name: 'Sam',
    age: 26,
    city: 'Midtown',
    distanceKm: 5,
    bio: 'Bike messenger by day, karaoke menace by night. Ask me about my worst gig.',
    interests: ['Cycling', 'Karaoke', 'Street food'],
    lookingFor: 'Chat & flirting',
    online: false,
    verified: false,
    likesYou: true,
    tint: ['#5B8CFF', '#B06BFF'],
  },
  {
    id: 'p7',
    name: 'Elena',
    age: 35,
    city: 'Lakeside',
    distanceKm: 8,
    bio: 'Two cats, one plant I have kept alive for years. Low pressure, high standards.',
    interests: ['Books', 'Cats', 'Hiking'],
    lookingFor: 'Friends with benefits',
    online: true,
    verified: true,
    likesYou: false,
    tint: ['#FF5C7A', '#FFB03A'],
  },
  {
    id: 'p8',
    name: 'Riley',
    age: 28,
    city: 'East Side',
    distanceKm: 7,
    bio: 'Bartender, night owl, professional over-sharer. Tell me your worst date story.',
    interests: ['Nightlife', 'Music', 'Dancing'],
    lookingFor: 'Dates & nights out',
    online: false,
    verified: false,
    likesYou: false,
    tint: ['#B06BFF', '#FF3D71'],
  },
];

export function findProfile(id: string): Profile | undefined {
  return SAMPLE_PROFILES.find((p) => p.id === id);
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 1).toUpperCase();
  return (parts[0].slice(0, 1) + parts[1].slice(0, 1)).toUpperCase();
}

export function timeAgo(at: number): string {
  const diff = Date.now() - at;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'now';
  if (mins < 60) return `${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  return `${days}d`;
}
