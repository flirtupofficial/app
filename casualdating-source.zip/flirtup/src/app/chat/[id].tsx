import Ionicons from '@expo/vector-icons/Ionicons';
import { Stack, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import {
  FlatList,
  KeyboardAvoidingView,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Avatar } from '@/components/avatar';
import { EmptyState } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { findProfile, SITE_URL, timeAgo, type ChatMessage } from '@/lib/data';

type Threads = Record<string, ChatMessage[]>;

const ICEBREAKERS = ['Hey! How is your week going?', 'Your playlist taste looks dangerous. Prove it.', 'Coffee or cocktails first?'];

export default function ChatScreen() {
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id: string }>();
  const profile = findProfile(String(id));
  const [threads, setThreads] = usePersistentState<Threads>('threads', {});
  const [text, setText] = useState('');

  if (!profile) {
    return (
      <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]}>
        <EmptyState icon="chatbubble-outline" title="Chat not found" />
      </SafeAreaView>
    );
  }

  const messages = threads[profile.id] ?? [];

  function send(body: string) {
    const trimmed = body.trim();
    if (!trimmed) return;
    const message: ChatMessage = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      from: 'me',
      text: trimmed,
      at: Date.now(),
    };
    setThreads((prev) => ({ ...prev, [profile!.id]: [...(prev[profile!.id] ?? []), message] }));
    setText('');
  }

  return (
    <SafeAreaView
      edges={['left', 'right', 'bottom']}
      style={[styles.root, { backgroundColor: colors.background }]}>
      <Stack.Screen options={{ title: profile.name }} />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={90}>
        <FlatList
          data={messages}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          ListHeaderComponent={
            <View style={styles.header}>
              <Avatar name={profile.name} tint={profile.tint} size={64} online={profile.online} />
              <Text style={[styles.headerName, { color: colors.text }]}>
                {profile.name}, {profile.age}
              </Text>
              <Text style={[styles.headerMeta, { color: colors.muted }]}>
                {profile.online ? 'Online now' : 'Recently active'} · {profile.city}
              </Text>
              <View style={[styles.notice, { backgroundColor: colors.surface }]}>
                <Ionicons name="lock-closed-outline" size={14} color={colors.primary} />
                <Text style={[styles.noticeText, { color: colors.muted }]}>
                  Messages stay on this phone. Open Flirtup to chat with real members.
                </Text>
              </View>
            </View>
          }
          renderItem={({ item }) => {
            const mine = item.from === 'me';
            return (
              <View style={[styles.bubbleRow, mine ? styles.mineRow : styles.themRow]}>
                <View
                  style={[
                    styles.bubble,
                    {
                      backgroundColor: mine ? colors.primary : colors.card,
                      borderColor: mine ? colors.primary : colors.border,
                    },
                  ]}>
                  <Text style={[styles.bubbleText, { color: mine ? colors.onPrimary : colors.text }]}>
                    {item.text}
                  </Text>
                  <Text
                    style={[
                      styles.time,
                      { color: mine ? colors.onPrimary : colors.muted, opacity: 0.7 },
                    ]}>
                    {timeAgo(item.at)}
                  </Text>
                </View>
              </View>
            );
          }}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={[styles.emptyTitle, { color: colors.text }]}>Say something good</Text>
              <Text style={[styles.emptyText, { color: colors.muted }]}>
                Try one of these openers:
              </Text>
              {ICEBREAKERS.map((line) => (
                <Pressable
                  key={line}
                  onPress={() => send(line)}
                  style={[styles.ice, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  <Text style={[styles.iceText, { color: colors.text }]}>{line}</Text>
                </Pressable>
              ))}
            </View>
          }
        />

        <View style={[styles.composer, { backgroundColor: colors.card, borderTopColor: colors.border }]}>
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder={`Message ${profile.name}`}
            placeholderTextColor={colors.muted}
            style={[styles.input, { color: colors.text, backgroundColor: colors.background, borderColor: colors.border }]}
            multiline
            maxLength={500}
            accessibilityLabel="Message"
          />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Send"
            onPress={() => send(text)}
            disabled={!text.trim()}
            style={[
              styles.send,
              { backgroundColor: text.trim() ? colors.primary : colors.border },
            ]}>
            <Ionicons name="send" size={18} color={colors.onPrimary} />
          </Pressable>
        </View>
        <Pressable onPress={() => Linking.openURL(SITE_URL)} style={styles.siteLink}>
          <Text style={[styles.siteText, { color: colors.muted }]}>Open Flirtup</Text>
        </Pressable>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  list: { padding: spacing.md, gap: spacing.sm, paddingBottom: spacing.md },
  header: { alignItems: 'center', gap: 4, marginBottom: spacing.md },
  headerName: { fontSize: 20, fontWeight: '800' },
  headerMeta: { fontSize: 13 },
  notice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.md,
    marginTop: spacing.sm,
  },
  noticeText: { flex: 1, fontSize: 12, lineHeight: 17 },
  bubbleRow: { flexDirection: 'row' },
  mineRow: { justifyContent: 'flex-end' },
  themRow: { justifyContent: 'flex-start' },
  bubble: {
    maxWidth: '80%',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm + 2,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 2,
  },
  bubbleText: { fontSize: 15, lineHeight: 21 },
  time: { fontSize: 10, alignSelf: 'flex-end' },
  empty: { gap: spacing.sm, paddingVertical: spacing.lg },
  emptyTitle: { fontSize: 18, fontWeight: '700', textAlign: 'center' },
  emptyText: { fontSize: 14, textAlign: 'center', marginBottom: spacing.xs },
  ice: {
    padding: spacing.md,
    borderRadius: radius.md,
    borderWidth: StyleSheet.hairlineWidth,
  },
  iceText: { fontSize: 14 },
  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: spacing.sm,
    padding: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  input: {
    flex: 1,
    minHeight: 44,
    maxHeight: 120,
    borderRadius: radius.lg,
    borderWidth: 1,
    paddingHorizontal: spacing.md,
    paddingTop: 12,
    paddingBottom: 12,
    fontSize: 15,
  },
  send: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  siteLink: { alignItems: 'center', paddingBottom: spacing.sm },
  siteText: { fontSize: 12, fontWeight: '600' },
});
