import { DarkTheme, DefaultTheme, ThemeProvider } from 'expo-router';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { ActivityIndicator, useColorScheme, View } from 'react-native';

import { AgeGate } from '@/components/age-gate';
import { useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';

export default function RootLayout() {
  const scheme = useColorScheme();
  const colors = useColors();
  const [ageVerified, setAgeVerified, status] = usePersistentState('ageVerified', false);

  if (status === 'loading') {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (!ageVerified) {
    return (
      <>
        <AgeGate onConfirm={() => setAgeVerified(true)} />
        <StatusBar style="auto" />
      </>
    );
  }

  return (
    <ThemeProvider value={scheme === 'dark' ? DarkTheme : DefaultTheme}>
      <Stack>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="person/[id]" options={{ title: 'Profile' }} />
        <Stack.Screen name="chat/[id]" options={{ title: 'Chat' }} />
        <Stack.Screen name="+not-found" options={{ title: 'Not found' }} />
      </Stack>
      <StatusBar style="auto" />
    </ThemeProvider>
  );
}
