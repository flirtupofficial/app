import Ionicons from '@expo/vector-icons/Ionicons';
import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';

import { Avatar } from '@/components/avatar';
import { Screen } from '@/components/screen';
import { Button, Card, EmptyState } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { SAMPLE_PROFILES, type Profile } from '@/lib/data';

type Filters = { maxDistance: number; onlineOnly: boolean };

export default function DiscoverScreen() {
  const colors = useColors();
  const [likes, setLikes] = usePersistentState<string[]>('likes', []);
  const [passes, setPasses] = usePersistentState<string[]>('passes', []);
  const [matches, setMatches] = usePersistentState<string[]>('matches', []);
  const [filters, setFilters] = usePersistentState<Filters>('filters', {
    maxDistance: 10,
    onlineOnly: false,
  });
  const [showFilters, setShowFilters] = useState(false);

  const deck = useMemo(
    () =>
      SAMPLE_PROFILES.filter(
        (p) =>
          !likes.includes(p.id) &&
          !passes.includes(p.id) &&
          p.distanceKm <= filters.maxDistance &&
          (!filters.onlineOnly || p.online),
      ).sort((a, b) => a.distanceKm - b.distanceKm),
    [likes, passes, filters],
  );

  function like(profile: Profile) {
    setLikes((prev) => (prev.includes(profile.id) ? prev : [...prev, profile.id]));
    if (profile.likesYou) {
      setMatches((prev) => (prev.includes(profile.id) ? prev : [...prev, profile.id]));
    }
  }

  function pass(profile: Profile) {
    setPasses((prev) => (prev.includes(profile.id) ? prev : [...prev, profile.id]));
  }

  function resetDeck() {
    setLikes([]);
    setPasses([]);
  }

  return (
    <Screen scroll={false}>
      <FlatList
        data={deck}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <View style={styles.header}>
            <View style={styles.headerRow}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.hello, { color: colors.muted }]}>Singles near you</Text>
                <Text style={[styles.title, { color: colors.text }]}>
                  {deck.length} {deck.length === 1 ? 'profile' : 'profiles'} to meet
                </Text>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Filters"
                onPress={() => setShowFilters((v) => !v)}
                style={[styles.iconBtn, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Ionicons name="options-outline" size={20} color={colors.text} />
              </Pressable>
            </View>

            {showFilters ? (
              <Card style={{ gap: spacing.sm }}>
                <Text style={[styles.filterLabel, { color: colors.text }]}>Max distance</Text>
                <View style={styles.chips}>
                  {[2, 5, 10, 25].map((km) => {
                    const active = filters.maxDistance === km;
                    return (
                      <Pressable
                        key={km}
                        onPress={() => setFilters({ ...filters, maxDistance: km })}
                        style={[
                          styles.chip,
                          {
                            backgroundColor: active ? colors.primary : colors.surface,
                            borderColor: active ? colors.primary : colors.border,
                          },
                        ]}>
                        <Text
                          style={[
                            styles.chipText,
                            { color: active ? colors.onPrimary : colors.text },
                          ]}>
                          {km} km
                        </Text>
                      </Pressable>
                    );
                  })}
                </View>
                <Pressable
                  onPress={() => setFilters({ ...filters, onlineOnly: !filters.onlineOnly })}
                  style={styles.toggleRow}>
                  <Ionicons
                    name={filters.onlineOnly ? 'checkbox' : 'square-outline'}
                    size={22}
                    color={filters.onlineOnly ? colors.primary : colors.muted}
                  />
                  <Text style={[styles.filterLabel, { color: colors.text }]}>Online now only</Text>
                </Pressable>
              </Card>
            ) : null}

            <View style={[styles.notice, { backgroundColor: colors.surface }]}>
              <Ionicons name="information-circle-outline" size={18} color={colors.primary} />
              <Text style={[styles.noticeText, { color: colors.muted }]}>
                Sample profiles for preview. Open Flirtup to browse real members near you.
              </Text>
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <Pressable
              onPress={() => router.push({ pathname: '/person/[id]', params: { id: item.id } })}
              style={styles.cardTop}>
              <Avatar name={item.name} tint={item.tint} size={64} online={item.online} />
              <View style={{ flex: 1, gap: 2 }}>
                <View style={styles.nameRow}>
                  <Text style={[styles.name, { color: colors.text }]}>
                    {item.name}, {item.age}
                  </Text>
                  {item.verified ? (
                    <Ionicons name="checkmark-circle" size={16} color={colors.primary} />
                  ) : null}
                </View>
                <Text style={[styles.meta, { color: colors.muted }]}>
                  {item.city} · {item.distanceKm} km away
                </Text>
                <Text style={[styles.meta, { color: colors.muted }]}>
                  {item.online ? 'Online now' : 'Recently active'} · {item.lookingFor}
                </Text>
              </View>
            </Pressable>

            <Text style={[styles.bio, { color: colors.text }]} numberOfLines={2}>
              {item.bio}
            </Text>

            <View style={styles.chips}>
              {item.interests.slice(0, 3).map((tag) => (
                <View
                  key={tag}
                  style={[styles.tag, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                  <Text style={[styles.tagText, { color: colors.muted }]}>{tag}</Text>
                </View>
              ))}
            </View>

            <View style={styles.actions}>
              <View style={{ flex: 1 }}>
                <Button title="Pass" variant="secondary" icon="close" onPress={() => pass(item)} />
              </View>
              <View style={{ flex: 1 }}>
                <Button title="Like" icon="heart" onPress={() => like(item)} />
              </View>
            </View>
          </Card>
        )}
        ListEmptyComponent={
          <EmptyState
            icon="flame-outline"
            title="You have seen everyone here"
            message="Widen your distance filter, or open Flirtup to meet real singles near you."
            actionTitle="Start over"
            onAction={resetDeck}
          />
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  list: { padding: spacing.md, gap: spacing.md, paddingBottom: spacing.xl },
  header: { gap: spacing.md, marginBottom: spacing.xs },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  hello: { fontSize: 13, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1 },
  title: { fontSize: 24, fontWeight: '800' },
  iconBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterLabel: { fontSize: 15, fontWeight: '600' },
  toggleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  notice: {
    flexDirection: 'row',
    gap: spacing.sm,
    padding: spacing.md,
    borderRadius: radius.md,
    alignItems: 'flex-start',
  },
  noticeText: { flex: 1, fontSize: 13, lineHeight: 19 },
  card: { gap: spacing.md },
  cardTop: { flexDirection: 'row', gap: spacing.md, alignItems: 'center' },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  name: { fontSize: 19, fontWeight: '700' },
  meta: { fontSize: 13 },
  bio: { fontSize: 15, lineHeight: 21 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: 1,
  },
  chipText: { fontSize: 13, fontWeight: '600' },
  tag: {
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 4,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },
  tagText: { fontSize: 12, fontWeight: '600' },
  actions: { flexDirection: 'row', gap: spacing.sm },
});
