import Constants from 'expo-constants';
import { StyleSheet, Text } from 'react-native';

import { Screen } from '@/components/screen';
import { useColors } from '@/constants/theme';

export default function SettingsScreen() {
  const colors = useColors();
  return (
    <Screen>
      <Text style={[styles.row, { color: colors.muted }]}>
        Version {Constants.expoConfig?.version ?? '1.0.0'}
      </Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  row: { fontSize: 15 },
});
