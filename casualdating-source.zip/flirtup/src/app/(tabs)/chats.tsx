import Ionicons from '@expo/vector-icons/Ionicons';
import { router } from 'expo-router';
import { FlatList, StyleSheet, Text, View } from 'react-native';

import { Avatar } from '@/components/avatar';
import { Screen } from '@/components/screen';
import { Card, EmptyState } from '@/components/ui';
import { spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { SAMPLE_PROFILES, timeAgo, type ChatMessage } from '@/lib/data';

type Threads = Record<string, ChatMessage[]>;

export default function ChatsScreen() {
  const colors = useColors();
  const [matches] = usePersistentState<string[]>('matches', []);
  const [threads] = usePersistentState<Threads>('threads', {});

  const rows = SAMPLE_PROFILES.filter((p) => matches.includes(p.id)).map((p) => {
    const messages = threads[p.id] ?? [];
    const last = messages[messages.length - 1];
    return { profile: p, last, count: messages.length };
  });

  return (
    <Screen scroll={false}>
      <FlatList
        data={rows}
        keyExtractor={(item) => item.profile.id}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <View style={styles.header}>
            <Text style={[styles.title, { color: colors.text }]}>Chats</Text>
            <Text style={[styles.sub, { color: colors.muted }]}>
              Conversations are saved on this phone.
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <Card
            onPress={() =>
              router.push({ pathname: '/chat/[id]', params: { id: item.profile.id } })
            }
            style={styles.row}>
            <Avatar
              name={item.profile.name}
              tint={item.profile.tint}
              size={52}
              online={item.profile.online}
            />
            <View style={{ flex: 1, gap: 2 }}>
              <View style={styles.nameRow}>
                <Text style={[styles.name, { color: colors.text }]}>{item.profile.name}</Text>
                {item.last ? (
                  <Text style={[styles.time, { color: colors.muted }]}>
                    {timeAgo(item.last.at)}
                  </Text>
                ) : null}
              </View>
              <Text
                style={[styles.preview, { color: item.last ? colors.muted : colors.primary }]}
                numberOfLines={1}>
                {item.last
                  ? `${item.last.from === 'me' ? 'You: ' : ''}${item.last.text}`
                  : 'New match — say hi'}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.muted} />
          </Card>
        )}
        ListEmptyComponent={
          <EmptyState
            icon="chatbubbles-outline"
            title="No conversations yet"
            message="Match with someone in Discover and your chats will appear here."
            actionTitle="Go to Discover"
            onAction={() => router.push('/')}
          />
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  list: { padding: spacing.md, gap: spacing.sm, paddingBottom: spacing.xl },
  header: { gap: spacing.xs, marginBottom: spacing.sm },
  title: { fontSize: 24, fontWeight: '800' },
  sub: { fontSize: 14 },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  nameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  name: { fontSize: 17, fontWeight: '700' },
  time: { fontSize: 12 },
  preview: { fontSize: 14 },
});
