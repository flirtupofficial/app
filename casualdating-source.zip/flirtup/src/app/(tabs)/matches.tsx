import Ionicons from '@expo/vector-icons/Ionicons';
import { router } from 'expo-router';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';

import { Avatar } from '@/components/avatar';
import { Screen } from '@/components/screen';
import { Card, EmptyState } from '@/components/ui';
import { spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { SAMPLE_PROFILES } from '@/lib/data';

export default function MatchesScreen() {
  const colors = useColors();
  const [matches] = usePersistentState<string[]>('matches', []);
  const [likes] = usePersistentState<string[]>('likes', []);

  const matched = SAMPLE_PROFILES.filter((p) => matches.includes(p.id));
  const liked = SAMPLE_PROFILES.filter((p) => likes.includes(p.id) && !matches.includes(p.id));

  return (
    <Screen scroll={false}>
      <FlatList
        data={matched}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListHeaderComponent={
          <View style={styles.header}>
            <Text style={[styles.title, { color: colors.text }]}>Your matches</Text>
            <Text style={[styles.sub, { color: colors.muted }]}>
              {matched.length === 0
                ? 'Like someone who likes you back and they land here.'
                : `${matched.length} ${matched.length === 1 ? 'person' : 'people'} liked you back.`}
            </Text>
            {liked.length > 0 ? (
              <Card style={styles.likedCard}>
                <View style={styles.likedRow}>
                  <Ionicons name="heart-half" size={20} color={colors.primary} />
                  <Text style={[styles.likedText, { color: colors.text }]}>
                    {liked.length} like{liked.length === 1 ? '' : 's'} waiting for a reply
                  </Text>
                </View>
                <View style={styles.avatarRow}>
                  {liked.map((p) => (
                    <Pressable
                      key={p.id}
                      onPress={() => router.push({ pathname: '/person/[id]', params: { id: p.id } })}>
                      <Avatar name={p.name} tint={p.tint} size={44} />
                    </Pressable>
                  ))}
                </View>
              </Card>
            ) : null}
          </View>
        }
        renderItem={({ item }) => (
          <Card
            onPress={() => router.push({ pathname: '/person/[id]', params: { id: item.id } })}
            style={styles.row}>
            <Avatar name={item.name} tint={item.tint} size={56} online={item.online} />
            <View style={{ flex: 1, gap: 2 }}>
              <Text style={[styles.name, { color: colors.text }]}>
                {item.name}, {item.age}
              </Text>
              <Text style={[styles.meta, { color: colors.muted }]} numberOfLines={1}>
                {item.city} · {item.lookingFor}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={colors.muted} />
          </Card>
        )}
        ListEmptyComponent={
          <EmptyState
            icon="heart-outline"
            title="No matches yet"
            message="Head to Discover and like a few profiles. Mutual likes show up here."
            actionTitle="Go to Discover"
            onAction={() => router.push('/')}
          />
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  list: { padding: spacing.md, gap: spacing.sm, paddingBottom: spacing.xl },
  header: { gap: spacing.sm, marginBottom: spacing.sm },
  title: { fontSize: 24, fontWeight: '800' },
  sub: { fontSize: 14, lineHeight: 20 },
  likedCard: { gap: spacing.sm, marginTop: spacing.sm },
  likedRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  likedText: { fontSize: 15, fontWeight: '600' },
  avatarRow: { flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  name: { fontSize: 17, fontWeight: '700' },
  meta: { fontSize: 13 },
});
