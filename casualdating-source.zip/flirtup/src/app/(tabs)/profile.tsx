import Constants from 'expo-constants';
import Ionicons from '@expo/vector-icons/Ionicons';
import { useState } from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';

import { Avatar } from '@/components/avatar';
import { Screen } from '@/components/screen';
import { Button, Card, ConfirmDialog, TextField } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { LOOKING_FOR_OPTIONS, SITE_URL, type MyProfile } from '@/lib/data';
import { removeKey } from '@/lib/storage';

const DATA_KEYS = ['myProfile', 'likes', 'passes', 'matches', 'threads'];

async function clearAllData(): Promise<void> {
  await Promise.all(DATA_KEYS.map((key) => removeKey(key).catch(() => undefined)));
}

const EMPTY: MyProfile = {
  name: '',
  age: '',
  city: '',
  bio: '',
  lookingFor: LOOKING_FOR_OPTIONS[0],
};

export default function ProfileScreen() {
  const colors = useColors();
  const [profile, setProfile] = usePersistentState<MyProfile>('myProfile', EMPTY);
  const [likes] = usePersistentState<string[]>('likes', []);
  const [matches] = usePersistentState<string[]>('matches', []);
  const [draft, setDraft] = useState<MyProfile>(profile);
  const [editing, setEditing] = useState(false);
  const [errors, setErrors] = useState<{ name?: string; age?: string }>({});
  const [confirmReset, setConfirmReset] = useState(false);

  function save() {
    const next: { name?: string; age?: string } = {};
    if (draft.name.trim().length < 2) next.name = 'Enter a name of at least 2 characters.';
    const age = Number(draft.age);
    if (!Number.isFinite(age) || age < 18 || age > 99) next.age = 'You must be 18 or older.';
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    setProfile({ ...draft, name: draft.name.trim(), city: draft.city.trim(), bio: draft.bio.trim() });
    setEditing(false);
  }

  return (
    <Screen>
      <Card style={styles.hero}>
        <Avatar name={profile.name || 'You'} tint={['#FF5C7A', '#B06BFF']} size={76} />
        <View style={{ flex: 1, gap: 2 }}>
          <Text style={[styles.name, { color: colors.text }]}>
            {profile.name ? `${profile.name}${profile.age ? `, ${profile.age}` : ''}` : 'Your profile'}
          </Text>
          <Text style={[styles.meta, { color: colors.muted }]}>
            {profile.city || 'Add your city'} · {profile.lookingFor}
          </Text>
        </View>
      </Card>

      <View style={styles.stats}>
        <Card style={styles.stat}>
          <Text style={[styles.statValue, { color: colors.primary }]}>{likes.length}</Text>
          <Text style={[styles.statLabel, { color: colors.muted }]}>Likes sent</Text>
        </Card>
        <Card style={styles.stat}>
          <Text style={[styles.statValue, { color: colors.primary }]}>{matches.length}</Text>
          <Text style={[styles.statLabel, { color: colors.muted }]}>Matches</Text>
        </Card>
      </View>

      {editing ? (
        <Card style={{ gap: spacing.md }}>
          <TextField
            label="Name"
            value={draft.name}
            onChangeText={(name) => setDraft({ ...draft, name })}
            placeholder="What should people call you?"
            error={errors.name}
            autoCapitalize="words"
          />
          <TextField
            label="Age"
            value={draft.age}
            onChangeText={(age) => setDraft({ ...draft, age: age.replace(/[^0-9]/g, '') })}
            placeholder="18+"
            keyboardType="number-pad"
            maxLength={2}
            error={errors.age}
          />
          <TextField
            label="City"
            value={draft.city}
            onChangeText={(city) => setDraft({ ...draft, city })}
            placeholder="Your area"
          />
          <TextField
            label="About you"
            value={draft.bio}
            onChangeText={(bio) => setDraft({ ...draft, bio })}
            placeholder="A line or two, keep it fun"
            multiline
            numberOfLines={4}
            style={{ minHeight: 96, paddingTop: spacing.sm, textAlignVertical: 'top' }}
            maxLength={240}
            hint={`${draft.bio.length}/240`}
          />
          <Text style={[styles.label, { color: colors.text }]}>Looking for</Text>
          <View style={styles.chips}>
            {LOOKING_FOR_OPTIONS.map((option) => {
              const active = draft.lookingFor === option;
              return (
                <Pressable
                  key={option}
                  onPress={() => setDraft({ ...draft, lookingFor: option })}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: active ? colors.primary : colors.surface,
                      borderColor: active ? colors.primary : colors.border,
                    },
                  ]}>
                  <Text style={[styles.chipText, { color: active ? colors.onPrimary : colors.text }]}>
                    {option}
                  </Text>
                </Pressable>
              );
            })}
          </View>
          <Button title="Save profile" icon="checkmark" onPress={save} />
          <Button
            title="Cancel"
            variant="ghost"
            onPress={() => {
              setDraft(profile);
              setErrors({});
              setEditing(false);
            }}
          />
        </Card>
      ) : (
        <Card style={{ gap: spacing.sm }}>
          <Text style={[styles.label, { color: colors.text }]}>About you</Text>
          <Text style={[styles.bio, { color: profile.bio ? colors.text : colors.muted }]}>
            {profile.bio || 'No bio yet. Add a few words so people know what you are about.'}
          </Text>
          <Button
            title="Edit profile"
            variant="secondary"
            icon="create-outline"
            onPress={() => {
              setDraft(profile);
              setEditing(true);
            }}
          />
        </Card>
      )}

      <Card style={{ gap: spacing.sm }}>
        <Text style={[styles.label, { color: colors.text }]}>Flirtup account</Text>
        <Text style={[styles.bio, { color: colors.muted }]}>
          Create your free profile on Flirtup to browse real singles near you and chat with
          members.
        </Text>
        <Button
          title="Open Flirtup"
          icon="open-outline"
          onPress={() => Linking.openURL(SITE_URL)}
        />
      </Card>

      <Card style={{ gap: spacing.sm }}>
        <Text style={[styles.label, { color: colors.text }]}>Stay safe</Text>
        {[
          'Meet in a public place for the first date.',
          'Tell a friend where you are going.',
          'Never send money or share financial details.',
          'Trust your instincts — block and report anything odd.',
        ].map((tip) => (
          <View key={tip} style={styles.tipRow}>
            <Ionicons name="shield-checkmark-outline" size={16} color={colors.primary} />
            <Text style={[styles.tip, { color: colors.muted }]}>{tip}</Text>
          </View>
        ))}
      </Card>

      <Card style={{ gap: spacing.sm }}>
        <Pressable onPress={() => Linking.openURL(`${SITE_URL}terms/`)} style={styles.linkRow}>
          <Text style={[styles.link, { color: colors.text }]}>Terms & Conditions</Text>
          <Ionicons name="chevron-forward" size={18} color={colors.muted} />
        </Pressable>
        <Pressable onPress={() => Linking.openURL(`${SITE_URL}privacy/`)} style={styles.linkRow}>
          <Text style={[styles.link, { color: colors.text }]}>Privacy Policy</Text>
          <Ionicons name="chevron-forward" size={18} color={colors.muted} />
        </Pressable>
        <Pressable onPress={() => setConfirmReset(true)} style={styles.linkRow}>
          <Text style={[styles.link, { color: colors.danger }]}>Clear my data on this phone</Text>
          <Ionicons name="trash-outline" size={18} color={colors.danger} />
        </Pressable>
      </Card>

      <Text style={[styles.version, { color: colors.muted }]}>
        Flirtup Casual Dating · v{Constants.expoConfig?.version ?? '1.0.0'} · 18+
      </Text>

      <ConfirmDialog
        visible={confirmReset}
        title="Clear your data?"
        message="Your profile, likes, matches and chats on this phone will be deleted."
        confirmTitle="Delete"
        cancelTitle="Keep"
        destructive
        onCancel={() => setConfirmReset(false)}
        onConfirm={() => {
          void clearAllData();
          setProfile(EMPTY);
          setDraft(EMPTY);
          setConfirmReset(false);
        }}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  name: { fontSize: 20, fontWeight: '800' },
  meta: { fontSize: 13 },
  stats: { flexDirection: 'row', gap: spacing.sm },
  stat: { flex: 1, alignItems: 'center', gap: 2 },
  statValue: { fontSize: 24, fontWeight: '800' },
  statLabel: { fontSize: 12, fontWeight: '600' },
  label: { fontSize: 15, fontWeight: '700' },
  bio: { fontSize: 14, lineHeight: 21 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.pill,
    borderWidth: 1,
  },
  chipText: { fontSize: 13, fontWeight: '600' },
  tipRow: { flexDirection: 'row', gap: spacing.sm, alignItems: 'flex-start' },
  tip: { flex: 1, fontSize: 13, lineHeight: 19 },
  linkRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  link: { fontSize: 15, fontWeight: '600' },
  version: { fontSize: 12, textAlign: 'center', marginTop: spacing.sm },
});
