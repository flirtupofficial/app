import Ionicons from '@expo/vector-icons/Ionicons';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';

import { Avatar } from '@/components/avatar';
import { Screen } from '@/components/screen';
import { Button, Card, EmptyState } from '@/components/ui';
import { radius, spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { findProfile, SITE_URL } from '@/lib/data';

export default function PersonScreen() {
  const colors = useColors();
  const { id } = useLocalSearchParams<{ id: string }>();
  const profile = findProfile(String(id));
  const [likes, setLikes] = usePersistentState<string[]>('likes', []);
  const [passes, setPasses] = usePersistentState<string[]>('passes', []);
  const [matches, setMatches] = usePersistentState<string[]>('matches', []);

  if (!profile) {
    return (
      <Screen>
        <EmptyState
          icon="person-outline"
          title="Profile not found"
          message="This profile is no longer available."
          actionTitle="Back to Discover"
          onAction={() => router.back()}
        />
      </Screen>
    );
  }

  const liked = likes.includes(profile.id);
  const matched = matches.includes(profile.id);

  function like() {
    setLikes((prev) => (prev.includes(profile!.id) ? prev : [...prev, profile!.id]));
    if (profile!.likesYou) {
      setMatches((prev) => (prev.includes(profile!.id) ? prev : [...prev, profile!.id]));
    }
  }

  function pass() {
    setPasses((prev) => (prev.includes(profile!.id) ? prev : [...prev, profile!.id]));
    router.back();
  }

  return (
    <Screen>
      <Stack.Screen options={{ title: profile.name }} />

      <Card style={styles.hero}>
        <Avatar name={profile.name} tint={profile.tint} size={96} online={profile.online} />
        <View style={styles.nameRow}>
          <Text style={[styles.name, { color: colors.text }]}>
            {profile.name}, {profile.age}
          </Text>
          {profile.verified ? (
            <Ionicons name="checkmark-circle" size={20} color={colors.primary} />
          ) : null}
        </View>
        <Text style={[styles.meta, { color: colors.muted }]}>
          {profile.city} · {profile.distanceKm} km away · {profile.online ? 'Online now' : 'Recently active'}
        </Text>
        <View style={[styles.pill, { backgroundColor: colors.surface }]}>
          <Ionicons name="sparkles" size={14} color={colors.primary} />
          <Text style={[styles.pillText, { color: colors.primary }]}>{profile.lookingFor}</Text>
        </View>
      </Card>

      <Card style={{ gap: spacing.sm }}>
        <Text style={[styles.section, { color: colors.text }]}>About</Text>
        <Text style={[styles.bio, { color: colors.text }]}>{profile.bio}</Text>
      </Card>

      <Card style={{ gap: spacing.sm }}>
        <Text style={[styles.section, { color: colors.text }]}>Interests</Text>
        <View style={styles.chips}>
          {profile.interests.map((tag) => (
            <View
              key={tag}
              style={[styles.tag, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.tagText, { color: colors.text }]}>{tag}</Text>
            </View>
          ))}
        </View>
      </Card>

      {matched ? (
        <Card style={{ gap: spacing.sm }}>
          <View style={styles.matchRow}>
            <Ionicons name="heart" size={20} color={colors.primary} />
            <Text style={[styles.section, { color: colors.text }]}>It is a match</Text>
          </View>
          <Button
            title="Send a message"
            icon="chatbubble-ellipses"
            onPress={() =>
              router.push({ pathname: '/chat/[id]', params: { id: profile.id } })
            }
          />
        </Card>
      ) : (
        <View style={styles.actions}>
          <View style={{ flex: 1 }}>
            <Button title="Pass" variant="secondary" icon="close" onPress={pass} />
          </View>
          <View style={{ flex: 1 }}>
            <Button
              title={liked ? 'Liked' : 'Like'}
              icon={liked ? 'heart' : 'heart-outline'}
              disabled={liked}
              onPress={like}
            />
          </View>
        </View>
      )}

      <Card style={{ gap: spacing.sm }}>
        <Text style={[styles.bio, { color: colors.muted }]}>
          This is a sample profile. To meet real members near you, open Flirtup.
        </Text>
        <Button
          title="Open Flirtup"
          variant="secondary"
          icon="open-outline"
          onPress={() => Linking.openURL(SITE_URL)}
        />
        <Pressable
          onPress={() => Linking.openURL(`${SITE_URL}terms/`)}
          style={styles.reportRow}>
          <Ionicons name="flag-outline" size={16} color={colors.muted} />
          <Text style={[styles.report, { color: colors.muted }]}>Report or block</Text>
        </Pressable>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.lg },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  name: { fontSize: 24, fontWeight: '800' },
  meta: { fontSize: 13, textAlign: 'center' },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
    marginTop: spacing.xs,
  },
  pillText: { fontSize: 13, fontWeight: '700' },
  section: { fontSize: 16, fontWeight: '700' },
  bio: { fontSize: 15, lineHeight: 22 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  tag: {
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
  },
  tagText: { fontSize: 13, fontWeight: '600' },
  matchRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  actions: { flexDirection: 'row', gap: spacing.sm },
  reportRow: { flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center' },
  report: { fontSize: 13, fontWeight: '600' },
});
